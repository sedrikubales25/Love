const correctPassword = "love"; // Change the password here
let messageText = "Happy Monthsarry, my love! Every moment with you is a treasure. " +
  "Your love fills my heart with joy, and I can't wait for all the months and years ahead. " +
  "You are my sunshine, my happiness, and my forever. I love you so much! 💖";

// Function to check password
function checkPassword() {
  let inputPassword = document.getElementById('password').value;
  
  if (inputPassword === correctPassword) {
    document.getElementById('message').style.display = "block";
    playMusic();
    animateMessage(messageText);
    createHearts();
  } else {
    alert("Wrong password! Try again.");
  }
}

// Function to Play Background Music
function playMusic() {
  let bgMusic = document.getElementById('bg-music');
  bgMusic.play();
}

// Function to animate message (fade-in one letter at a time)
function animateMessage(message) {
  let messageElement = document.getElementById('text');
  messageElement.innerHTML = '';  
  let index = 0;
  
  function showLetter() {
    if (index < message.length) {
      let span = document.createElement('span');
      span.innerText = message[index];
      span.classList.add('fade-in');
      span.style.animationDelay = `${index * 0.1}s`; // Delay for smooth effect
      messageElement.appendChild(span);
      index++;
      setTimeout(showLetter, 100);
    }
  }
  showLetter();
}

// Function to create falling hearts
function createHearts() {
  setInterval(() => {
    let heart = document.createElement('div');
    heart.innerHTML = "&#10084;&#65039;";
    heart.classList.add('heart');
    
    let randomSize = Math.random() * 20 + 10;
    heart.style.fontSize = randomSize + "px";
    
    let randomX = Math.random() * window.innerWidth;
    heart.style.left = randomX + "px";
    
    let duration = Math.random() * 3 + 2;
    heart.style.animationDuration = duration + "s";
    
    document.getElementById('heart-container').appendChild(heart);
    
    setTimeout(() => {
      heart.remove();
    }, duration * 1000);
  }, 300);
}
